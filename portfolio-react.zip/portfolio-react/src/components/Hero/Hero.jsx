import React from 'react';
import "./Hero.css";
import profile_picsss from "../../assets/profile_picsss.png";
import AnchorLink from "react-anchor-link-smooth-scroll";

const Hero = () => {
  return (
    <div id="home" className='hero'>
      <img src={profile_picsss} alt="hero.image"/>
      <h1><span>I'm Abhisek Mohanty,</span> frontend developer based in India.</h1>
      <p>I am a frontend developer from Pune, India, with 2+ years of experience at Infosys, a multinational company. </p>
      <div className='hero-action'>
        <AnchorLink className='hero-connect' href='#contact'>Connect with me</AnchorLink>
        <a className='hero-resume' href='/Resume.pdf' download>My resume</a>
      </div>
    </div>
  )
}

export default Hero;
